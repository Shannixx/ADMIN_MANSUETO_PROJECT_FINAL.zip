using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace AdminMansuetoProject
{
    public class LogsForm : Form
    {
        DataGridView dgv;
        TextBox txtSearch;
        Button btnSearch, btnBack, btnLoad;

        public LogsForm()
        {
            Text = "Logs - ADMIN MANSUETO";
            Width = 900; Height = 600; StartPosition = FormStartPosition.CenterScreen;
            Initialize();
            LoadLogs();
        }

        private void Initialize()
        {
            dgv = new DataGridView { Left = 20, Top = 60, Width = 840, Height = 450, ReadOnly = true, SelectionMode = DataGridViewSelectionMode.FullRowSelect };

            txtSearch = new TextBox { Left = 20, Top = 20, Width = 300 };
            btnSearch = new Button { Left = 330, Top = 18, Text = "Search", Width = 80 }; btnSearch.Click += BtnSearch_Click;
            btnLoad = new Button { Left = 420, Top = 18, Text = "Reload", Width = 80 }; btnLoad.Click += (s,e)=> LoadLogs();
            btnBack = new Button { Left = 760, Top = 18, Text = "Back", Width = 100 }; btnBack.Click += (s,e)=> this.Close();

            Controls.AddRange(new Control[] { dgv, txtSearch, btnSearch, btnLoad, btnBack });
        }

        private void LoadLogs()
        {
            try
            {
                var dt = DBHelper.ExecuteSelect("sp_GetAllLogs");
                dgv.DataSource = dt;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                var p = new SqlParameter("@Search", txtSearch.Text);
                var dt = DBHelper.ExecuteSelect("sp_SearchLogs", p);
                dgv.DataSource = dt;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
    }
}
