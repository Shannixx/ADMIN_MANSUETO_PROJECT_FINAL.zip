using System;
using System.Drawing;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

namespace AdminMansuetoProject
{
    public class LoginForm : Form
    {
        TextBox txtUsername;
        TextBox txtPassword;
        CheckBox chkShowPassword;
        Button btnLogin;
        Button btnRegister;
        Button btnForgotPassword;
        int loginAttempts = 0;
        Label lblMessage;

        public LoginForm()
        {
            Text = "ADMIN MANSUETO - Login";
            Width = 400;
            Height = 320;
            StartPosition = FormStartPosition.CenterScreen;
            Initialize();
        }

        private void Initialize()
        {
            Label lblUser = new Label { Text = "Username", Left = 30, Top = 30, Width = 80 };
            txtUsername = new TextBox { Left = 120, Top = 25, Width = 200, Name = "txtUsername" };

            Label lblPass = new Label { Text = "Password", Left = 30, Top = 70, Width = 80 };
            txtPassword = new TextBox { Left = 120, Top = 65, Width = 200, UseSystemPasswordChar = true, Name = "txtPassword" };

            chkShowPassword = new CheckBox { Left = 120, Top = 95, Text = "Show Password" };
            chkShowPassword.CheckedChanged += (s, e) => txtPassword.UseSystemPasswordChar = !chkShowPassword.Checked;

            btnLogin = new Button { Text = "Login", Left = 120, Top = 130, Width = 95 };
            btnLogin.Click += BtnLogin_Click;

            btnRegister = new Button { Text = "Register", Left = 225, Top = 130, Width = 95 };
            btnRegister.Click += (s, e) => { new RegistrationForm().Show(); this.Hide(); };

            btnForgotPassword = new Button { Text = "Forgot Password", Left = 120, Top = 170, Width = 200 };
            btnForgotPassword.Click += (s, e) => MessageBox.Show("Password recovery placeholder. Contact admin.", "Forgot Password");

            lblMessage = new Label { Left = 30, Top = 210, Width = 320, ForeColor = Color.Red };

            Controls.AddRange(new Control[] { lblUser, txtUsername, lblPass, txtPassword, chkShowPassword, btnLogin, btnRegister, btnForgotPassword, lblMessage });
        }

        private string HashPassword(string plain)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] bytes = Encoding.UTF8.GetBytes(plain);
                byte[] hash = sha.ComputeHash(bytes);
                StringBuilder sb = new StringBuilder();
                foreach (var b in hash) sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            lblMessage.Text = "";
            if (string.IsNullOrWhiteSpace(txtUsername.Text) || string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                lblMessage.Text = "Username and Password are required.";
                return;
            }

            string hash = HashPassword(txtPassword.Text);

            // Hardcoded admin fallback
            if (txtUsername.Text == "admin" && txtPassword.Text == "admin123")
            {
                var dash = new AdminDashboard("Administrator");
                dash.Show();
                this.Hide();
                return;
            }

            try
            {
                var p1 = new SqlParameter("@Username", txtUsername.Text);
                var p2 = new SqlParameter("@PasswordHash", hash);
                DataTable dt = DBHelper.ExecuteSelect("sp_LoginUser", p1, p2);
                if (dt.Rows.Count > 0)
                {
                    string role = dt.Rows[0]["Role"].ToString();
                    string username = dt.Rows[0]["Username"].ToString();
                    if (role == "Admin" || username.ToLower() == "admin")
                    {
                        var dash = new AdminDashboard(username, Convert.ToInt32(dt.Rows[0]["Id"]));
                        dash.Show();
                        this.Hide();
                        return;
                    }
                    else if (role == "Student")
                    {
                        var sd = new StudentDashboard(username);
                        sd.Show();
                        this.Hide();
                        return;
                    }
                    else if (role == "Teacher")
                    {
                        var td = new TeacherDashboard(username);
                        td.Show();
                        this.Hide();
                        return;
                    }
                }
                else
                {
                    loginAttempts++;
                    if (loginAttempts >= 3)
                    {
                        MessageBox.Show("Maximum attempts reached. Login disabled.", "Locked", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        btnLogin.Enabled = false;
                        return;
                    }
                    MessageBox.Show("Incorrect username or password.", "Login failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Login error: " + ex.Message);
            }
        }
    }
}
