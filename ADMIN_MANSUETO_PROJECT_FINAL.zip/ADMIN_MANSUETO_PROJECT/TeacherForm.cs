using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace AdminMansuetoProject
{
    public class TeacherForm : Form
    {
        DataGridView dgv;
        TextBox txtName, txtGender, txtSearch;
        Button btnAdd, btnUpdate, btnDelete, btnSearch, btnBack;
        int selectedId = -1;

        public TeacherForm()
        {
            Text = "Teachers - ADMIN MANSUETO";
            Width = 900; Height = 600; StartPosition = FormStartPosition.CenterScreen;
            Initialize();
            LoadTeachers();
        }

        private void Initialize()
        {
            dgv = new DataGridView { Left = 20, Top = 60, Width = 840, Height = 350, ReadOnly = true, SelectionMode = DataGridViewSelectionMode.FullRowSelect };
            dgv.CellClick += Dgv_CellClick;

            Label lblName = new Label { Left = 20, Top = 430, Text = "Name" }; txtName = new TextBox { Left = 80, Top = 425, Width = 200 };
            Label lblGender = new Label { Left = 300, Top = 430, Text = "Gender" }; txtGender = new TextBox { Left = 360, Top = 425, Width = 120 };

            btnAdd = new Button { Left = 780, Top = 420, Text = "Add", Width = 80 }; btnAdd.Click += BtnAdd_Click;
            btnUpdate = new Button { Left = 780, Top = 460, Text = "Update", Width = 80 }; btnUpdate.Click += BtnUpdate_Click;
            btnDelete = new Button { Left = 780, Top = 500, Text = "Delete", Width = 80 }; btnDelete.Click += BtnDelete_Click;

            txtSearch = new TextBox { Left = 20, Top = 20, Width = 300 };
            btnSearch = new Button { Left = 330, Top = 18, Text = "Search", Width = 80 }; btnSearch.Click += BtnSearch_Click;

            btnBack = new Button { Left = 430, Top = 18, Text = "Back", Width = 80 }; btnBack.Click += (s, e) => this.Close();

            Controls.AddRange(new Control[] { dgv, lblName, txtName, lblGender, txtGender, btnAdd, btnUpdate, btnDelete, txtSearch, btnSearch, btnBack });
        }

        private void LoadTeachers()
        {
            try
            {
                DataTable dt = DBHelper.ExecuteSelect("sp_GetAllTeachers");
                dgv.DataSource = dt;
            }
            catch (Exception ex) { MessageBox.Show("Error loading teachers: " + ex.Message); }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text)) { MessageBox.Show("Name required"); return; }
            try
            {
                DBHelper.ExecuteNonQuery("sp_AddTeacher",
                    new SqlParameter("@Name", txtName.Text),
                    new SqlParameter("@Gender", txtGender.Text));
                DBHelper.ExecuteNonQuery("sp_AddLog",
                    new SqlParameter("@Action", "Added teacher: " + txtName.Text),
                    new SqlParameter("@PerformedBy", "Admin"));
                MessageBox.Show("Teacher added.");
                LoadTeachers();
                ClearFields();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            if (selectedId == -1) { MessageBox.Show("Select a teacher to update."); return; }
            var confirm = MessageBox.Show("Update record?", "Confirm", MessageBoxButtons.YesNo);
            if (confirm != DialogResult.Yes) return;
            try
            {
                DBHelper.ExecuteNonQuery("sp_UpdateTeacher",
                    new SqlParameter("@Id", selectedId),
                    new SqlParameter("@Name", txtName.Text),
                    new SqlParameter("@Gender", txtGender.Text));
                DBHelper.ExecuteNonQuery("sp_AddLog",
                    new SqlParameter("@Action", "Updated teacher: " + txtName.Text),
                    new SqlParameter("@PerformedBy", "Admin"));
                MessageBox.Show("Updated.");
                LoadTeachers();
                ClearFields();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (selectedId == -1) { MessageBox.Show("Select a teacher to delete."); return; }
            var confirm = MessageBox.Show("Delete record?", "Confirm", MessageBoxButtons.YesNo);
            if (confirm != DialogResult.Yes) return;
            try
            {
                DBHelper.ExecuteNonQuery("sp_DeleteTeacher", new SqlParameter("@Id", selectedId));
                DBHelper.ExecuteNonQuery("sp_AddLog",
                    new SqlParameter("@Action", "Deleted teacher id: " + selectedId),
                    new SqlParameter("@PerformedBy", "Admin"));
                MessageBox.Show("Deleted.");
                LoadTeachers();
                ClearFields();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                var p = new SqlParameter("@Search", txtSearch.Text);
                DataTable dt = DBHelper.ExecuteSelect("sp_SearchTeachers", p);
                dgv.DataSource = dt;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void Dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                selectedId = Convert.ToInt32(dgv.Rows[e.RowIndex].Cells["Id"].Value);
                txtName.Text = dgv.Rows[e.RowIndex].Cells["Name"].Value?.ToString();
                txtGender.Text = dgv.Rows[e.RowIndex].Cells["Gender"].Value?.ToString();
            }
        }

        private void ClearFields()
        {
            selectedId = -1;
            txtName.Text = ""; txtGender.Text = "";
        }
    }
}
