using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace AdminMansuetoProject
{
    public class ReportsForm : Form
    {
        DataGridView dgv;
        Button btnPrintCsv, btnLoadStudents, btnLoadTeachers, btnLoadSubjects, btnLoadStudentsBySubject, btnLoadStudentsByTeacher, btnBack;
        ComboBox cmbSubjects, cmbTeachers;

        public ReportsForm()
        {
            Text = "Reports - ADMIN MANSUETO";
            Width = 1000; Height = 700; StartPosition = FormStartPosition.CenterScreen;
            Initialize();
            LoadSubjects();
            LoadTeachers();
        }

        private void Initialize()
        {
            dgv = new DataGridView { Left = 20, Top = 120, Width = 940, Height = 480, ReadOnly = true, SelectionMode = DataGridViewSelectionMode.FullRowSelect };

            btnLoadStudents = new Button { Left = 20, Top = 20, Text = "All Active Students", Width = 160 }; btnLoadStudents.Click += (s, e) => LoadAllStudents();
            btnLoadTeachers = new Button { Left = 200, Top = 20, Text = "All Active Teachers", Width = 160 }; btnLoadTeachers.Click += (s, e) => LoadAllTeachers();
            btnLoadSubjects = new Button { Left = 380, Top = 20, Text = "All Subjects", Width = 160 }; btnLoadSubjects.Click += (s, e) => LoadAllSubjects();

            cmbSubjects = new ComboBox { Left = 20, Top = 60, Width = 240, DropDownStyle = ComboBoxStyle.DropDownList };
            btnLoadStudentsBySubject = new Button { Left = 280, Top = 60, Text = "Students per Subject", Width = 160 }; btnLoadStudentsBySubject.Click += BtnLoadStudentsBySubject_Click;

            cmbTeachers = new ComboBox { Left = 460, Top = 60, Width = 240, DropDownStyle = ComboBoxStyle.DropDownList };
            btnLoadStudentsByTeacher = new Button { Left = 720, Top = 60, Text = "Students per Teacher", Width = 160 }; btnLoadStudentsByTeacher.Click += BtnLoadStudentsByTeacher_Click;

            btnPrintCsv = new Button { Left = 860, Top = 20, Text = "Export CSV", Width = 100 }; btnPrintCsv.Click += BtnPrintCsv_Click;
            btnBack = new Button { Left = 860, Top = 60, Text = "Back", Width = 100 }; btnBack.Click += (s,e)=> this.Close();

            Controls.AddRange(new Control[] { dgv, btnLoadStudents, btnLoadTeachers, btnLoadSubjects, cmbSubjects, btnLoadStudentsBySubject, cmbTeachers, btnLoadStudentsByTeacher, btnPrintCsv, btnBack });
        }

        private void LoadAllStudents()
        {
            try
            {
                var dt = DBHelper.ExecuteSelect("sp_GetAllStudents");
                dgv.DataSource = dt;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void LoadAllTeachers()
        {
            try
            {
                var dt = DBHelper.ExecuteSelect("sp_GetAllTeachers");
                dgv.DataSource = dt;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void LoadAllSubjects()
        {
            try
            {
                var dt = DBHelper.ExecuteSelect("sp_GetAllSubjects");
                dgv.DataSource = dt;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void LoadSubjects()
        {
            try
            {
                var dt = DBHelper.ExecuteSelect("sp_GetAllSubjects");
                cmbSubjects.Items.Clear();
                foreach (DataRow r in dt.Rows)
                {
                    cmbSubjects.Items.Add(new ComboboxItem { Text = r["Title"].ToString(), Value = r["Id"] });
                }
                if (cmbSubjects.Items.Count > 0) cmbSubjects.SelectedIndex = 0;
            }
            catch { }
        }

        private void LoadTeachers()
        {
            try
            {
                var dt = DBHelper.ExecuteSelect("sp_GetAllTeachers");
                cmbTeachers.Items.Clear();
                foreach (DataRow r in dt.Rows)
                {
                    cmbTeachers.Items.Add(new ComboboxItem { Text = r["Name"].ToString(), Value = r["Id"] });
                }
                if (cmbTeachers.Items.Count > 0) cmbTeachers.SelectedIndex = 0;
            }
            catch { }
        }

        private void BtnLoadStudentsBySubject_Click(object sender, EventArgs e)
        {
            if (cmbSubjects.SelectedItem == null) return;
            var item = (ComboboxItem)cmbSubjects.SelectedItem;
            try
            {
                var p = new SqlParameter("@SubjectId", Convert.ToInt32(item.Value));
                var dt = DBHelper.ExecuteSelect("sp_GetStudentsBySubject", p);
                dgv.DataSource = dt;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnLoadStudentsByTeacher_Click(object sender, EventArgs e)
        {
            if (cmbTeachers.SelectedItem == null) return;
            var item = (ComboboxItem)cmbTeachers.SelectedItem;
            try
            {
                var p = new SqlParameter("@TeacherId", Convert.ToInt32(item.Value));
                var dt = DBHelper.ExecuteSelect("sp_GetStudentsPerTeacher", p);
                dgv.DataSource = dt;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnPrintCsv_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgv.DataSource == null) { MessageBox.Show("No data to export."); return; }
                using (SaveFileDialog sfd = new SaveFileDialog() { Filter = "CSV files (*.csv)|*.csv", FileName = "report.csv" })
                {
                    if (sfd.ShowDialog() == DialogResult.OK)
                    {
                        var dt = (DataTable)dgv.DataSource;
                        System.Text.StringBuilder sb = new System.Text.StringBuilder();

                        // headers
                        for (int i = 0; i < dt.Columns.Count; i++)
                        {
                            sb.Append(dt.Columns[i].ColumnName);
                            if (i < dt.Columns.Count - 1) sb.Append(",");
                        }
                        sb.AppendLine();

                        // rows
                        foreach (DataRow row in dt.Rows)
                        {
                            for (int i = 0; i < dt.Columns.Count; i++)
                            {
                                var val = row[i]?.ToString().Replace(",", " ");
                                sb.Append(val);
                                if (i < dt.Columns.Count - 1) sb.Append(",");
                            }
                            sb.AppendLine();
                        }

                        System.IO.File.WriteAllText(sfd.FileName, sb.ToString());
                        MessageBox.Show("Exported to " + sfd.FileName);
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        // helper combobox item
        private class ComboboxItem
        {
            public string Text { get; set; }
            public object Value { get; set; }
            public override string ToString() => Text;
        }
    }
}
