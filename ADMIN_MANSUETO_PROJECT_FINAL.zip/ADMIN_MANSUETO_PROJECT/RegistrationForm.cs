using System;
using System.Drawing;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

namespace AdminMansuetoProject
{
    public class RegistrationForm : Form
    {
        TextBox txtUsername;
        TextBox txtPassword;
        CheckBox chkShow;
        ComboBox cmbRole;
        Button btnRegister;
        Button btnBack;

        public RegistrationForm()
        {
            Text = "Register - ADMIN MANSUETO";
            Width = 400;
            Height = 360;
            StartPosition = FormStartPosition.CenterScreen;
            Initialize();
        }

        private void Initialize()
        {
            Label lblUser = new Label { Text = "Username", Left = 30, Top = 30 };
            txtUsername = new TextBox { Left = 120, Top = 25, Width = 220 };

            Label lblPass = new Label { Text = "Password", Left = 30, Top = 70 };
            txtPassword = new TextBox { Left = 120, Top = 65, Width = 220, UseSystemPasswordChar = true };

            chkShow = new CheckBox { Left = 120, Top = 95, Text = "Show Password" };
            chkShow.CheckedChanged += (s, e) => txtPassword.UseSystemPasswordChar = !chkShow.Checked;

            Label lblRole = new Label { Text = "Role", Left = 30, Top = 130 };
            cmbRole = new ComboBox { Left = 120, Top = 125, Width = 220, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbRole.Items.AddRange(new string[] { "Student", "Teacher" });

            btnRegister = new Button { Text = "Register", Left = 120, Top = 170, Width = 100 };
            btnRegister.Click += BtnRegister_Click;

            btnBack = new Button { Text = "Back", Left = 245, Top = 170, Width = 95 };
            btnBack.Click += (s, e) => { new LoginForm().Show(); this.Hide(); };

            Controls.AddRange(new Control[] { lblUser, txtUsername, lblPass, txtPassword, chkShow, lblRole, cmbRole, btnRegister, btnBack });
        }

        private string HashPassword(string plain)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] bytes = Encoding.UTF8.GetBytes(plain);
                byte[] hash = sha.ComputeHash(bytes);
                StringBuilder sb = new StringBuilder();
                foreach (var b in hash) sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }

        private void BtnRegister_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUsername.Text) || string.IsNullOrWhiteSpace(txtPassword.Text) || cmbRole.SelectedIndex == -1)
            {
                MessageBox.Show("Complete all fields.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var role = cmbRole.SelectedItem.ToString();
            string hash = HashPassword(txtPassword.Text);

            try
            {
                var p1 = new SqlParameter("@Username", txtUsername.Text);
                var p2 = new SqlParameter("@PasswordHash", hash);
                var p3 = new SqlParameter("@Role", role);
                DBHelper.ExecuteNonQuery("sp_AddUser", p1, p2, p3);
                MessageBox.Show($"Registered as {role}. Redirecting...", "Registered");

                if (role == "Student")
                {
                    var sDash = new StudentDashboard(txtUsername.Text);
                    sDash.Show();
                    this.Hide();
                }
                else
                {
                    var tDash = new TeacherDashboard(txtUsername.Text);
                    tDash.Show();
                    this.Hide();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Registration failed: " + ex.Message);
            }
        }
    }
}
