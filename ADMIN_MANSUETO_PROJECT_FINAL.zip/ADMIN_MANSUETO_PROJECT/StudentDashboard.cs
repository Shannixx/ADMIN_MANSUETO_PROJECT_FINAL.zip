using System;
using System.Drawing;
using System.Windows.Forms;

namespace AdminMansuetoProject
{
    public class StudentDashboard : Form
    {
        Label lblWelcome;
        public StudentDashboard(string username)
        {
            Text = "Student Dashboard";
            Width = 600; Height = 400; StartPosition = FormStartPosition.CenterScreen;
            lblWelcome = new Label { Left = 20, Top = 20, Text = $"Welcome, {username}", Font = new Font("Segoe UI", 12) };
            Controls.Add(lblWelcome);
        }
    }
}
