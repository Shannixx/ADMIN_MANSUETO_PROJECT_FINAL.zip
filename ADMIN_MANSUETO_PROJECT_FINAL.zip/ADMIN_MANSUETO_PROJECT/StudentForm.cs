using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace AdminMansuetoProject
{
    public class StudentForm : Form
    {
        DataGridView dgv;
        TextBox txtName, txtGender, txtCourse, txtSearch;
        Button btnAdd, btnUpdate, btnDelete, btnSearch, btnBack;
        int selectedId = -1;

        public StudentForm()
        {
            Text = "Students - ADMIN MANSUETO";
            Width = 900; Height = 600; StartPosition = FormStartPosition.CenterScreen;
            Initialize();
            LoadStudents();
        }

        private void Initialize()
        {
            dgv = new DataGridView { Left = 20, Top = 60, Width = 840, Height = 350, ReadOnly = true, SelectionMode = DataGridViewSelectionMode.FullRowSelect };
            dgv.CellClick += Dgv_CellClick;

            Label lblName = new Label { Left = 20, Top = 430, Text = "Name" }; txtName = new TextBox { Left = 80, Top = 425, Width = 200 };
            Label lblGender = new Label { Left = 300, Top = 430, Text = "Gender" }; txtGender = new TextBox { Left = 360, Top = 425, Width = 120 };
            Label lblCourse = new Label { Left = 500, Top = 430, Text = "Course" }; txtCourse = new TextBox { Left = 560, Top = 425, Width = 200 };

            btnAdd = new Button { Left = 780, Top = 420, Text = "Add", Width = 80 }; btnAdd.Click += BtnAdd_Click;
            btnUpdate = new Button { Left = 780, Top = 460, Text = "Update", Width = 80 }; btnUpdate.Click += BtnUpdate_Click;
            btnDelete = new Button { Left = 780, Top = 500, Text = "Delete", Width = 80 }; btnDelete.Click += BtnDelete_Click;

            txtSearch = new TextBox { Left = 20, Top = 20, Width = 300 };
            btnSearch = new Button { Left = 330, Top = 18, Text = "Search", Width = 80 }; btnSearch.Click += BtnSearch_Click;

            btnBack = new Button { Left = 430, Top = 18, Text = "Back", Width = 80 }; btnBack.Click += (s, e) => this.Close();

            Controls.AddRange(new Control[] { dgv, lblName, txtName, lblGender, txtGender, lblCourse, txtCourse, btnAdd, btnUpdate, btnDelete, txtSearch, btnSearch, btnBack });
        }

        private void LoadStudents()
        {
            try
            {
                DataTable dt = DBHelper.ExecuteSelect("sp_GetAllStudents"); // create this sp to return active students ordered desc
                dgv.DataSource = dt;
            }
            catch (Exception ex) { MessageBox.Show("Error loading students: " + ex.Message); }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text)) { MessageBox.Show("Name required"); return; }
            try
            {
                var p1 = new SqlParameter("@Name", txtName.Text);
                var p2 = new SqlParameter("@Gender", txtGender.Text);
                var p3 = new SqlParameter("@Course", txtCourse.Text);
                DBHelper.ExecuteNonQuery("sp_AddStudent", p1, p2, p3);
                DBHelper.ExecuteNonQuery("sp_AddLog",
                    new SqlParameter("@Action", "Added student: " + txtName.Text),
                    new SqlParameter("@PerformedBy", "Admin"));
                MessageBox.Show("Student added.");
                LoadStudents();
                ClearFields();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            if (selectedId == -1) { MessageBox.Show("Select a student to update."); return; }
            var confirm = MessageBox.Show("Update record?", "Confirm", MessageBoxButtons.YesNo);
            if (confirm != DialogResult.Yes) return;
            try
            {
                DBHelper.ExecuteNonQuery("sp_UpdateStudent",
                    new SqlParameter("@Id", selectedId),
                    new SqlParameter("@Name", txtName.Text),
                    new SqlParameter("@Gender", txtGender.Text),
                    new SqlParameter("@Course", txtCourse.Text));
                DBHelper.ExecuteNonQuery("sp_AddLog",
                    new SqlParameter("@Action", "Updated student: " + txtName.Text),
                    new SqlParameter("@PerformedBy", "Admin"));
                MessageBox.Show("Updated.");
                LoadStudents();
                ClearFields();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (selectedId == -1) { MessageBox.Show("Select a student to delete."); return; }
            var confirm = MessageBox.Show("Delete record?", "Confirm", MessageBoxButtons.YesNo);
            if (confirm != DialogResult.Yes) return;
            try
            {
                DBHelper.ExecuteNonQuery("sp_DeleteStudent", new SqlParameter("@Id", selectedId));
                DBHelper.ExecuteNonQuery("sp_AddLog",
                    new SqlParameter("@Action", "Deleted student id: " + selectedId),
                    new SqlParameter("@PerformedBy", "Admin"));
                MessageBox.Show("Deleted.");
                LoadStudents();
                ClearFields();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                var p = new SqlParameter("@Search", txtSearch.Text);
                DataTable dt = DBHelper.ExecuteSelect("sp_SearchStudents", p);
                dgv.DataSource = dt;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void Dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                selectedId = Convert.ToInt32(dgv.Rows[e.RowIndex].Cells["Id"].Value);
                txtName.Text = dgv.Rows[e.RowIndex].Cells["Name"].Value?.ToString();
                txtGender.Text = dgv.Rows[e.RowIndex].Cells["Gender"].Value?.ToString();
                txtCourse.Text = dgv.Rows[e.RowIndex].Cells["Course"].Value?.ToString();
            }
        }

        private void ClearFields()
        {
            selectedId = -1;
            txtName.Text = ""; txtGender.Text = ""; txtCourse.Text = "";
        }
    }
}
