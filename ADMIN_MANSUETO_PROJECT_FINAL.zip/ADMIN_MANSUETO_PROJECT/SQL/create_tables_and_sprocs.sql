-- Run this in SSMS. Change DB name if needed.
IF DB_ID('ADMIN_MANSUETO_DB') IS NULL
BEGIN
    CREATE DATABASE ADMIN_MANSUETO_DB;
END
GO

USE ADMIN_MANSUETO_DB;
GO

-- Tables
IF OBJECT_ID('dbo.Students','U') IS NULL
BEGIN
CREATE TABLE dbo.Students (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100),
    Gender NVARCHAR(20),
    Course NVARCHAR(100),
    IsActive BIT DEFAULT 1
);
END
GO

IF OBJECT_ID('dbo.Teachers','U') IS NULL
BEGIN
CREATE TABLE dbo.Teachers (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100),
    Gender NVARCHAR(20),
    IsActive BIT DEFAULT 1
);
END
GO

IF OBJECT_ID('dbo.Subjects','U') IS NULL
BEGIN
CREATE TABLE dbo.Subjects (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Title NVARCHAR(100),
    Description NVARCHAR(255),
    IsActive BIT DEFAULT 1
);
END
GO

-- Mapping tables
IF OBJECT_ID('dbo.StudentSubjects','U') IS NULL
BEGIN
CREATE TABLE dbo.StudentSubjects (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    StudentId INT NOT NULL,
    SubjectId INT NOT NULL,
    CONSTRAINT FK_StudentSubjects_Students FOREIGN KEY (StudentId) REFERENCES dbo.Students(Id),
    CONSTRAINT FK_StudentSubjects_Subjects FOREIGN KEY (SubjectId) REFERENCES dbo.Subjects(Id)
);
END
GO

IF OBJECT_ID('dbo.TeacherSubjects','U') IS NULL
BEGIN
CREATE TABLE dbo.TeacherSubjects (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    TeacherId INT NOT NULL,
    SubjectId INT NOT NULL,
    CONSTRAINT FK_TeacherSubjects_Teachers FOREIGN KEY (TeacherId) REFERENCES dbo.Teachers(Id),
    CONSTRAINT FK_TeacherSubjects_Subjects FOREIGN KEY (SubjectId) REFERENCES dbo.Subjects(Id)
);
END
GO

IF OBJECT_ID('dbo.Logs','U') IS NULL
BEGIN
CREATE TABLE dbo.Logs (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Action NVARCHAR(200),
    PerformedBy NVARCHAR(100),
    DateCreated DATETIME DEFAULT GETDATE()
);
END
GO

-- Stored Procedures: Students
IF OBJECT_ID('sp_AddStudent','P') IS NOT NULL DROP PROCEDURE sp_AddStudent;
GO
CREATE PROCEDURE sp_AddStudent
    @Name NVARCHAR(100),
    @Gender NVARCHAR(20),
    @Course NVARCHAR(100)
AS
BEGIN
    INSERT INTO Students (Name, Gender, Course, IsActive)
    VALUES (@Name, @Gender, @Course, 1);
END
GO

IF OBJECT_ID('sp_GetAllStudents','P') IS NOT NULL DROP PROCEDURE sp_GetAllStudents;
GO
CREATE PROCEDURE sp_GetAllStudents
AS
BEGIN
    SELECT Id, Name, Gender, Course, IsActive
    FROM Students
    WHERE IsActive = 1
    ORDER BY Id DESC;
END
GO

IF OBJECT_ID('sp_UpdateStudent','P') IS NOT NULL DROP PROCEDURE sp_UpdateStudent;
GO
CREATE PROCEDURE sp_UpdateStudent
    @Id INT,
    @Name NVARCHAR(100),
    @Gender NVARCHAR(20),
    @Course NVARCHAR(100)
AS
BEGIN
    UPDATE Students SET Name=@Name, Gender=@Gender, Course=@Course WHERE Id=@Id;
END
GO

IF OBJECT_ID('sp_DeleteStudent','P') IS NOT NULL DROP PROCEDURE sp_DeleteStudent;
GO
CREATE PROCEDURE sp_DeleteStudent
    @Id INT
AS
BEGIN
    DELETE FROM Students WHERE Id=@Id;
END
GO

IF OBJECT_ID('sp_SearchStudents','P') IS NOT NULL DROP PROCEDURE sp_SearchStudents;
GO
CREATE PROCEDURE sp_SearchStudents
    @Search NVARCHAR(100)
AS
BEGIN
    SELECT Id, Name, Gender, Course, IsActive
    FROM Students
    WHERE (Name LIKE '%' + @Search + '%' OR Gender LIKE '%' + @Search + '%' OR Course LIKE '%' + @Search + '%')
    ORDER BY Id DESC;
END
GO

-- Stored Procedures: Teachers
IF OBJECT_ID('sp_AddTeacher','P') IS NOT NULL DROP PROCEDURE sp_AddTeacher;
GO
CREATE PROCEDURE sp_AddTeacher
    @Name NVARCHAR(100),
    @Gender NVARCHAR(20)
AS
BEGIN
    INSERT INTO Teachers (Name, Gender, IsActive)
    VALUES (@Name, @Gender, 1);
END
GO

IF OBJECT_ID('sp_GetAllTeachers','P') IS NOT NULL DROP PROCEDURE sp_GetAllTeachers;
GO
CREATE PROCEDURE sp_GetAllTeachers
AS
BEGIN
    SELECT Id, Name, Gender, IsActive
    FROM Teachers
    WHERE IsActive = 1
    ORDER BY Id DESC;
END
GO

IF OBJECT_ID('sp_UpdateTeacher','P') IS NOT NULL DROP PROCEDURE sp_UpdateTeacher;
GO
CREATE PROCEDURE sp_UpdateTeacher
    @Id INT,
    @Name NVARCHAR(100),
    @Gender NVARCHAR(20)
AS
BEGIN
    UPDATE Teachers SET Name=@Name, Gender=@Gender WHERE Id=@Id;
END
GO

IF OBJECT_ID('sp_DeleteTeacher','P') IS NOT NULL DROP PROCEDURE sp_DeleteTeacher;
GO
CREATE PROCEDURE sp_DeleteTeacher
    @Id INT
AS
BEGIN
    DELETE FROM Teachers WHERE Id=@Id;
END
GO

IF OBJECT_ID('sp_SearchTeachers','P') IS NOT NULL DROP PROCEDURE sp_SearchTeachers;
GO
CREATE PROCEDURE sp_SearchTeachers
    @Search NVARCHAR(100)
AS
BEGIN
    SELECT Id, Name, Gender, IsActive
    FROM Teachers
    WHERE (Name LIKE '%' + @Search + '%' OR Gender LIKE '%' + @Search + '%')
    ORDER BY Id DESC;
END
GO

-- Stored Procedures: Subjects
IF OBJECT_ID('sp_AddSubject','P') IS NOT NULL DROP PROCEDURE sp_AddSubject;
GO
CREATE PROCEDURE sp_AddSubject
    @Title NVARCHAR(100),
    @Description NVARCHAR(255)
AS
BEGIN
    INSERT INTO Subjects (Title, Description, IsActive)
    VALUES (@Title, @Description, 1);
END
GO

IF OBJECT_ID('sp_GetAllSubjects','P') IS NOT NULL DROP PROCEDURE sp_GetAllSubjects;
GO
CREATE PROCEDURE sp_GetAllSubjects
AS
BEGIN
    SELECT Id, Title, Description, IsActive
    FROM Subjects
    WHERE IsActive = 1
    ORDER BY Id DESC;
END
GO

IF OBJECT_ID('sp_UpdateSubject','P') IS NOT NULL DROP PROCEDURE sp_UpdateSubject;
GO
CREATE PROCEDURE sp_UpdateSubject
    @Id INT,
    @Title NVARCHAR(100),
    @Description NVARCHAR(255)
AS
BEGIN
    UPDATE Subjects SET Title=@Title, Description=@Description WHERE Id=@Id;
END
GO

IF OBJECT_ID('sp_DeleteSubject','P') IS NOT NULL DROP PROCEDURE sp_DeleteSubject;
GO
CREATE PROCEDURE sp_DeleteSubject
    @Id INT
AS
BEGIN
    DELETE FROM Subjects WHERE Id=@Id;
END
GO

IF OBJECT_ID('sp_SearchSubjects','P') IS NOT NULL DROP PROCEDURE sp_SearchSubjects;
GO
CREATE PROCEDURE sp_SearchSubjects
    @Search NVARCHAR(100)
AS
BEGIN
    SELECT Id, Title, Description, IsActive
    FROM Subjects
    WHERE (Title LIKE '%' + @Search + '%' OR Description LIKE '%' + @Search + '%')
    ORDER BY Id DESC;
END
GO

-- Mapping and Reports
IF OBJECT_ID('sp_GetStudentsBySubject','P') IS NOT NULL DROP PROCEDURE sp_GetStudentsBySubject;
GO
CREATE PROCEDURE sp_GetStudentsBySubject
    @SubjectId INT
AS
BEGIN
    SELECT s.Id, s.Name, s.Gender, s.Course
    FROM Students s
    INNER JOIN StudentSubjects ss ON s.Id = ss.StudentId
    WHERE ss.SubjectId = @SubjectId AND s.IsActive = 1
    ORDER BY s.Id DESC;
END
GO

IF OBJECT_ID('sp_GetStudentsPerTeacher','P') IS NOT NULL DROP PROCEDURE sp_GetStudentsPerTeacher;
GO
CREATE PROCEDURE sp_GetStudentsPerTeacher
    @TeacherId INT
AS
BEGIN
    SELECT DISTINCT s.Id, s.Name, s.Gender, s.Course
    FROM Students s
    INNER JOIN StudentSubjects ss ON s.Id = ss.StudentId
    INNER JOIN TeacherSubjects ts ON ts.SubjectId = ss.SubjectId
    WHERE ts.TeacherId = @TeacherId AND s.IsActive = 1
    ORDER BY s.Id DESC;
END
GO

-- Logs
IF OBJECT_ID('sp_AddLog','P') IS NOT NULL DROP PROCEDURE sp_AddLog;
GO
CREATE PROCEDURE sp_AddLog
    @Action NVARCHAR(200),
    @PerformedBy NVARCHAR(100)
AS
BEGIN
    INSERT INTO Logs (Action, PerformedBy) VALUES (@Action, @PerformedBy);
END
GO

IF OBJECT_ID('sp_GetAllLogs','P') IS NOT NULL DROP PROCEDURE sp_GetAllLogs;
GO
CREATE PROCEDURE sp_GetAllLogs
AS
BEGIN
    SELECT Id, Action, PerformedBy, DateCreated FROM Logs ORDER BY Id DESC;
END
GO

IF OBJECT_ID('sp_SearchLogs','P') IS NOT NULL DROP PROCEDURE sp_SearchLogs;
GO
CREATE PROCEDURE sp_SearchLogs
    @Search NVARCHAR(200)
AS
BEGIN
    SELECT Id, Action, PerformedBy, DateCreated
    FROM Logs
    WHERE (Action LIKE '%' + @Search + '%' OR PerformedBy LIKE '%' + @Search + '%')
    ORDER BY Id DESC;
END
GO

-- Optional: procedures to assign student/teacher to subject
IF OBJECT_ID('sp_AssignStudentToSubject','P') IS NOT NULL DROP PROCEDURE sp_AssignStudentToSubject;
GO
CREATE PROCEDURE sp_AssignStudentToSubject
    @StudentId INT,
    @SubjectId INT
AS
BEGIN
    INSERT INTO StudentSubjects (StudentId, SubjectId) VALUES (@StudentId, @SubjectId);
END
GO

IF OBJECT_ID('sp_AssignTeacherToSubject','P') IS NOT NULL DROP PROCEDURE sp_AssignTeacherToSubject;
GO
CREATE PROCEDURE sp_AssignTeacherToSubject
    @TeacherId INT,
    @SubjectId INT
AS
BEGIN
    INSERT INTO TeacherSubjects (TeacherId, SubjectId) VALUES (@TeacherId, @SubjectId);
END
GO


-- Users table and auth procedures
IF OBJECT_ID('dbo.Users','U') IS NULL
BEGIN
CREATE TABLE dbo.Users (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(100) UNIQUE,
    PasswordHash NVARCHAR(256),
    Role NVARCHAR(50),
    ProfileImage NVARCHAR(255),
    IsActive BIT DEFAULT 1
);
END
GO

IF OBJECT_ID('sp_AddUser','P') IS NOT NULL DROP PROCEDURE sp_AddUser;
GO
CREATE PROCEDURE sp_AddUser
    @Username NVARCHAR(100),
    @PasswordHash NVARCHAR(256),
    @Role NVARCHAR(50)
AS
BEGIN
    INSERT INTO Users (Username, PasswordHash, Role, IsActive)
    VALUES (@Username, @PasswordHash, @Role, 1);
END
GO

IF OBJECT_ID('sp_LoginUser','P') IS NOT NULL DROP PROCEDURE sp_LoginUser;
GO
CREATE PROCEDURE sp_LoginUser
    @Username NVARCHAR(100),
    @PasswordHash NVARCHAR(256)
AS
BEGIN
    SELECT Id, Username, Role FROM Users WHERE Username = @Username AND PasswordHash = @PasswordHash AND IsActive = 1;
END
GO

IF OBJECT_ID('sp_UpdateUserProfile','P') IS NOT NULL DROP PROCEDURE sp_UpdateUserProfile;
GO
CREATE PROCEDURE sp_UpdateUserProfile
    @UserId INT,
    @ProfileImage NVARCHAR(255)
AS
BEGIN
    UPDATE Users SET ProfileImage = @ProfileImage WHERE Id = @UserId;
END
GO


IF OBJECT_ID('sp_GetUserById','P') IS NOT NULL DROP PROCEDURE sp_GetUserById;
GO
CREATE PROCEDURE sp_GetUserById
    @UserId INT
AS
BEGIN
    SELECT Id, Username, ProfileImage, Role FROM Users WHERE Id = @UserId;
END
GO
