# ADMIN_MANSUETO_PROJECT - WinForms (.NET Framework)

This package contains a ready-to-open Windows Forms (.NET Framework) project skeleton with UI forms and example DB scripts.

## What is included
- Visual Studio project file (AdminMansuetoProject.csproj)
- C# source files:
  - Program.cs
  - DBHelper.cs
  - LoginForm.cs
  - RegistrationForm.cs
  - AdminDashboard.cs
  - StudentDashboard.cs
  - TeacherDashboard.cs
  - StudentForm.cs
  - TeacherForm.cs
  - SubjectForm.cs
  - ReportsForm.cs
  - LogsForm.cs
- App.config (update connection string)
- SQL/create_tables_and_sprocs.sql (create DB, tables, stored procedures)
- Properties/AssemblyInfo.cs

## Quick Setup (step-by-step)
1. Unzip the project (ADMIN_MANSUETO_PROJECT.zip) and open the folder in Visual Studio:
   - File -> Open -> Project/Solution -> select `AdminMansuetoProject.csproj`.
2. Add References (if missing):
   - Right-click **References** -> Add Reference -> Assemblies -> Framework -> check:
     - System.Configuration
     - System.Windows.Forms.DataVisualization
3. Update connection string:
   - Open `App.config` and replace `YOUR_SERVER_NAME` with your SQL Server instance name.
   - Ensure SQL Server is running and accessible.
4. Create database objects:
   - Open SQL Server Management Studio (SSMS).
   - Run the script `SQL/create_tables_and_sprocs.sql`. This will:
     - Create database `ADMIN_MANSUETO_DB` (if not exists).
     - Create tables: Students, Teachers, Subjects, StudentSubjects, TeacherSubjects, Logs.
     - Create stored procedures used by the app.
5. Build and Run:
   - Build -> Build Solution.
   - Run the app.
   - Login (hardcoded admin): `admin` / `admin123`.
6. Usage:
   - Admin Dashboard -> Students/Teachers/Subjects to manage records.
   - Reports -> export CSV for data.
   - Logs -> view activity logs recorded when you add/update/delete records.

## Notes
- The project is a starting skeleton. You can expand it:
  - Add authentication (Users table, password hashing).
  - Improve UI styling via Designer instead of programmatic creation.
  - Add student-subject assignment UI (use sp_AssignStudentToSubject).
  - Add file storage for profile pictures.
- For any errors connecting to DB, check App.config connection string and SQL Server accessibility.
