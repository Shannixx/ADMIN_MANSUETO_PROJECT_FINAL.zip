using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace AdminMansuetoProject
{
    public class AssignmentForm : Form
    {
        ComboBox cmbStudents, cmbSubjects, cmbTeachers;
        Button btnAssignStudent, btnAssignTeacher, btnBack;

        public AssignmentForm()
        {
            Text = "Assignments - ADMIN MANSUETO";
            Width = 700; Height = 300; StartPosition = FormStartPosition.CenterScreen;
            Initialize();
            LoadStudents();
            LoadSubjects();
            LoadTeachers();
        }

        private void Initialize()
        {
            Label l1 = new Label { Left = 20, Top = 20, Text = "Student:" };
            cmbStudents = new ComboBox { Left = 90, Top = 18, Width = 220, DropDownStyle = ComboBoxStyle.DropDownList };

            Label l2 = new Label { Left = 20, Top = 60, Text = "Subject:" };
            cmbSubjects = new ComboBox { Left = 90, Top = 58, Width = 220, DropDownStyle = ComboBoxStyle.DropDownList };

            btnAssignStudent = new Button { Left = 330, Top = 38, Width = 120, Text = "Assign Student" };
            btnAssignStudent.Click += BtnAssignStudent_Click;

            Label l3 = new Label { Left = 20, Top = 110, Text = "Teacher:" };
            cmbTeachers = new ComboBox { Left = 90, Top = 108, Width = 220, DropDownStyle = ComboBoxStyle.DropDownList };
            btnAssignTeacher = new Button { Left = 330, Top = 108, Width = 120, Text = "Assign Teacher" };
            btnAssignTeacher.Click += BtnAssignTeacher_Click;

            btnBack = new Button { Left = 500, Top = 200, Width = 80, Text = "Back" };
            btnBack.Click += (s,e)=> this.Close();

            Controls.AddRange(new Control[] { l1, cmbStudents, l2, cmbSubjects, btnAssignStudent, l3, cmbTeachers, btnAssignTeacher, btnBack });
        }

        private void LoadStudents()
        {
            try
            {
                var dt = DBHelper.ExecuteSelect("sp_GetAllStudents");
                cmbStudents.Items.Clear();
                foreach (DataRow r in dt.Rows) cmbStudents.Items.Add(new ComboItem { Text = r["Name"].ToString(), Value = r["Id"] });
                if (cmbStudents.Items.Count > 0) cmbStudents.SelectedIndex = 0;
            }
            catch { }
        }

        private void LoadSubjects()
        {
            try
            {
                var dt = DBHelper.ExecuteSelect("sp_GetAllSubjects");
                cmbSubjects.Items.Clear();
                foreach (DataRow r in dt.Rows) cmbSubjects.Items.Add(new ComboItem { Text = r["Title"].ToString(), Value = r["Id"] });
                if (cmbSubjects.Items.Count > 0) cmbSubjects.SelectedIndex = 0;
            }
            catch { }
        }

        private void LoadTeachers()
        {
            try
            {
                var dt = DBHelper.ExecuteSelect("sp_GetAllTeachers");
                cmbTeachers.Items.Clear();
                foreach (DataRow r in dt.Rows) cmbTeachers.Items.Add(new ComboItem { Text = r["Name"].ToString(), Value = r["Id"] });
                if (cmbTeachers.Items.Count > 0) cmbTeachers.SelectedIndex = 0;
            }
            catch { }
        }

        private void BtnAssignStudent_Click(object sender, EventArgs e)
        {
            if (cmbStudents.SelectedItem == null || cmbSubjects.SelectedItem == null) return;
            var s = (ComboItem)cmbStudents.SelectedItem;
            var sub = (ComboItem)cmbSubjects.SelectedItem;
            try
            {
                DBHelper.ExecuteNonQuery("sp_AssignStudentToSubject",
                    new SqlParameter("@StudentId", (int)s.Value),
                    new SqlParameter("@SubjectId", (int)sub.Value));
                MessageBox.Show("Student assigned to subject.");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnAssignTeacher_Click(object sender, EventArgs e)
        {
            if (cmbTeachers.SelectedItem == null || cmbSubjects.SelectedItem == null) return;
            var t = (ComboItem)cmbTeachers.SelectedItem;
            var sub = (ComboItem)cmbSubjects.SelectedItem;
            try
            {
                DBHelper.ExecuteNonQuery("sp_AssignTeacherToSubject",
                    new SqlParameter("@TeacherId", (int)t.Value),
                    new SqlParameter("@SubjectId", (int)sub.Value));
                MessageBox.Show("Teacher assigned to subject.");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private class ComboItem { public string Text; public object Value; public override string ToString() => Text; }
    }
}
