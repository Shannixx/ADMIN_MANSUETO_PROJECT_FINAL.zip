using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace AdminMansuetoProject
{
    public class SubjectForm : Form
    {
        DataGridView dgv;
        TextBox txtTitle, txtDescription, txtSearch;
        Button btnAdd, btnUpdate, btnDelete, btnSearch, btnBack;
        int selectedId = -1;

        public SubjectForm()
        {
            Text = "Subjects - ADMIN MANSUETO";
            Width = 900; Height = 600; StartPosition = FormStartPosition.CenterScreen;
            Initialize();
            LoadSubjects();
        }

        private void Initialize()
        {
            dgv = new DataGridView { Left = 20, Top = 60, Width = 840, Height = 350, ReadOnly = true, SelectionMode = DataGridViewSelectionMode.FullRowSelect };
            dgv.CellClick += Dgv_CellClick;

            Label lblTitle = new Label { Left = 20, Top = 430, Text = "Title" }; txtTitle = new TextBox { Left = 80, Top = 425, Width = 200 };
            Label lblDesc = new Label { Left = 300, Top = 430, Text = "Description" }; txtDescription = new TextBox { Left = 380, Top = 425, Width = 380 };

            btnAdd = new Button { Left = 780, Top = 420, Text = "Add", Width = 80 }; btnAdd.Click += BtnAdd_Click;
            btnUpdate = new Button { Left = 780, Top = 460, Text = "Update", Width = 80 }; btnUpdate.Click += BtnUpdate_Click;
            btnDelete = new Button { Left = 780, Top = 500, Text = "Delete", Width = 80 }; btnDelete.Click += BtnDelete_Click;

            txtSearch = new TextBox { Left = 20, Top = 20, Width = 300 };
            btnSearch = new Button { Left = 330, Top = 18, Text = "Search", Width = 80 }; btnSearch.Click += BtnSearch_Click;

            btnBack = new Button { Left = 430, Top = 18, Text = "Back", Width = 80 }; btnBack.Click += (s, e) => this.Close();

            Controls.AddRange(new Control[] { dgv, lblTitle, txtTitle, lblDesc, txtDescription, btnAdd, btnUpdate, btnDelete, txtSearch, btnSearch, btnBack });
        }

        private void LoadSubjects()
        {
            try
            {
                DataTable dt = DBHelper.ExecuteSelect("sp_GetAllSubjects");
                dgv.DataSource = dt;
            }
            catch (Exception ex) { MessageBox.Show("Error loading subjects: " + ex.Message); }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTitle.Text)) { MessageBox.Show("Title required"); return; }
            try
            {
                DBHelper.ExecuteNonQuery("sp_AddSubject",
                    new SqlParameter("@Title", txtTitle.Text),
                    new SqlParameter("@Description", txtDescription.Text));
                DBHelper.ExecuteNonQuery("sp_AddLog",
                    new SqlParameter("@Action", "Added subject: " + txtTitle.Text),
                    new SqlParameter("@PerformedBy", "Admin"));
                MessageBox.Show("Subject added.");
                LoadSubjects();
                ClearFields();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            if (selectedId == -1) { MessageBox.Show("Select a subject to update."); return; }
            var confirm = MessageBox.Show("Update record?", "Confirm", MessageBoxButtons.YesNo);
            if (confirm != DialogResult.Yes) return;
            try
            {
                DBHelper.ExecuteNonQuery("sp_UpdateSubject",
                    new SqlParameter("@Id", selectedId),
                    new SqlParameter("@Title", txtTitle.Text),
                    new SqlParameter("@Description", txtDescription.Text));
                DBHelper.ExecuteNonQuery("sp_AddLog",
                    new SqlParameter("@Action", "Updated subject: " + txtTitle.Text),
                    new SqlParameter("@PerformedBy", "Admin"));
                MessageBox.Show("Updated.");
                LoadSubjects();
                ClearFields();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (selectedId == -1) { MessageBox.Show("Select a subject to delete."); return; }
            var confirm = MessageBox.Show("Delete record?", "Confirm", MessageBoxButtons.YesNo);
            if (confirm != DialogResult.Yes) return;
            try
            {
                DBHelper.ExecuteNonQuery("sp_DeleteSubject", new SqlParameter("@Id", selectedId));
                DBHelper.ExecuteNonQuery("sp_AddLog",
                    new SqlParameter("@Action", "Deleted subject id: " + selectedId),
                    new SqlParameter("@PerformedBy", "Admin"));
                MessageBox.Show("Deleted.");
                LoadSubjects();
                ClearFields();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                var p = new SqlParameter("@Search", txtSearch.Text);
                DataTable dt = DBHelper.ExecuteSelect("sp_SearchSubjects", p);
                dgv.DataSource = dt;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void Dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                selectedId = Convert.ToInt32(dgv.Rows[e.RowIndex].Cells["Id"].Value);
                txtTitle.Text = dgv.Rows[e.RowIndex].Cells["Title"].Value?.ToString();
                txtDescription.Text = dgv.Rows[e.RowIndex].Cells["Description"].Value?.ToString();
            }
        }

        private void ClearFields()
        {
            selectedId = -1;
            txtTitle.Text = ""; txtDescription.Text = "";
        }
    }
}
