using System;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Data;
using System.Data.SqlClient;

namespace AdminMansuetoProject
{
    public class AdminDashboard : Form
    {
        Label lblUsername;
        PictureBox picProfile;
        Button btnLogout;
        Button btnStudents, btnTeachers, btnSubjects, btnReports, btnLogs;
        Button btnUploadPic;
        Chart chartSample;
        int currentUserId = -1;
        string currentUsername = "";

        public AdminDashboard(string username, int userId = -1)
        {
            Text = "Admin Dashboard - ADMIN MANSUETO";
            Width = 900;
            Height = 600;
            StartPosition = FormStartPosition.CenterScreen;
            currentUserId = userId;
            currentUsername = username;
            Initialize(username);
            LoadProfileImage();
        }

        private void Initialize(string username)
        {
            picProfile = new PictureBox { Left = 20, Top = 20, Width = 80, Height = 80, BorderStyle = BorderStyle.FixedSingle, SizeMode = PictureBoxSizeMode.Zoom };
            lblUsername = new Label { Left = 110, Top = 35, Text = username, Font = new Font("Segoe UI", 12, FontStyle.Bold) };

            btnUploadPic = new Button { Left = 110, Top = 65, Width = 100, Text = "Upload Pic" };
            btnUploadPic.Click += BtnUploadPic_Click;

            btnLogout = new Button { Left = 760, Top = 20, Width = 100, Text = "Logout" };
            btnLogout.Click += (s, e) => { new LoginForm().Show(); this.Close(); };

            btnStudents = new Button { Left = 20, Top = 120, Width = 160, Text = "Students" };
            btnTeachers = new Button { Left = 20, Top = 160, Width = 160, Text = "Teachers" };
            btnSubjects = new Button { Left = 20, Top = 200, Width = 160, Text = "Subjects" };
            btnReports = new Button { Left = 20, Top = 240, Width = 160, Text = "Reports" };
            var btnAssign = new Button { Left = 20, Top = 320, Width = 160, Text = "Assignments" };
            btnLogs = new Button { Left = 20, Top = 280, Width = 160, Text = "Logs" };
            btnAssign.Click += (s, e) => { new AssignmentForm().ShowDialog(); };

            btnStudents.Click += (s, e) => { new StudentForm().ShowDialog(); };
            btnTeachers.Click += (s, e) => { new TeacherForm().ShowDialog(); };
            btnSubjects.Click += (s, e) => { new SubjectForm().ShowDialog(); };
            btnReports.Click += (s, e) => { new ReportsForm().ShowDialog(); };
            btnLogs.Click += (s, e) => { new LogsForm().ShowDialog(); };

            chartSample = new Chart { Left = 220, Top = 120, Width = 560, Height = 360 };
            chartSample.ChartAreas.Add(new ChartArea("Area1"));
            var seriesPie = new Series("StudentsByCourse") { ChartType = SeriesChartType.Pie };
            seriesPie.Points.AddXY("Course A", 40);
            seriesPie.Points.AddXY("Course B", 60);
            chartSample.Series.Add(seriesPie);

            Controls.AddRange(new Control[] { picProfile, lblUsername, btnUploadPic, btnLogout, btnStudents, btnTeachers, btnSubjects, btnReports, btnLogs, btnAssign, chartSample });
        }

        private void BtnUploadPic_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog() { Filter = "Images|*.png;*.jpg;*.jpeg;*.bmp" })
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    string path = ofd.FileName;
                    try
                    {
                        if (currentUserId > 0)
                        {
                            DBHelper.ExecuteNonQuery("sp_UpdateUserProfile",
                                new SqlParameter("@UserId", currentUserId),
                                new SqlParameter("@ProfileImage", path));
                        }
                        picProfile.Image = Image.FromFile(path);
                        MessageBox.Show("Profile updated.");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error saving profile image: " + ex.Message);
                    }
                }
            }
        }

        private void LoadProfileImage()
        {
            if (currentUserId <= 0) return;
            try
            {
                var dt = DBHelper.ExecuteSelect("sp_GetUserById", new SqlParameter("@UserId", currentUserId));
                if (dt.Rows.Count > 0)
                {
                    var imgPath = dt.Rows[0]["ProfileImage"]?.ToString();
                    if (!string.IsNullOrWhiteSpace(imgPath) && System.IO.File.Exists(imgPath))
                    {
                        picProfile.Image = Image.FromFile(imgPath);
                    }
                }
            }
            catch { }
        }
    }
}
